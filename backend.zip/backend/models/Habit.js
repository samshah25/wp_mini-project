import mongoose from "mongoose";

const completionSchema = new mongoose.Schema({
  date: { type: Date, required: true }
});

const habitSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    name: { type: String, required: true },
    goalPerWeek: { type: Number, default: 7 }, // times per week
    completions: [completionSchema]
  },
  { timestamps: true }
);

export default mongoose.model("Habit", habitSchema);
