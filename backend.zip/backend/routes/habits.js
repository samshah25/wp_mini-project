import express from "express";
import Habit from "../models/Habit.js";
import { auth } from "../middleware/auth.js";

const router = express.Router();

// Get all habits of logged-in user
router.get("/", auth, async (req, res) => {
  try {
    const habits = await Habit.find({ user: req.user.id }).sort({
      createdAt: -1
    });
    res.json(habits);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

// Create a habit
router.post("/", auth, async (req, res) => {
  try {
    const { name, goalPerWeek } = req.body;
    if (!name) return res.status(400).json({ message: "Name required" });

    const habit = await Habit.create({
      user: req.user.id,
      name,
      goalPerWeek: goalPerWeek || 7
    });

    res.status(201).json(habit);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

// Mark habit done for today
router.patch("/:id/complete", auth, async (req, res) => {
  try {
    const habit = await Habit.findOne({ _id: req.params.id, user: req.user.id });
    if (!habit) return res.status(404).json({ message: "Habit not found" });

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const alreadyDone = habit.completions.some((c) => {
      const d = new Date(c.date);
      d.setHours(0, 0, 0, 0);
      return d.getTime() === today.getTime();
    });

    if (alreadyDone) {
      return res.status(400).json({ message: "Already completed today" });
    }

    habit.completions.push({ date: new Date() });
    await habit.save();

    res.json(habit);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

// Delete habit
router.delete("/:id", auth, async (req, res) => {
  try {
    const habit = await Habit.findOneAndDelete({
      _id: req.params.id,
      user: req.user.id
    });
    if (!habit) return res.status(404).json({ message: "Habit not found" });

    res.json({ message: "Habit deleted" });
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

export default router;
