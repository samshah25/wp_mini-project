import React, { useEffect, useState } from "react";
import Navbar from "./components/Navbar.jsx";
import AuthForm from "./components/AuthForm.jsx";
import HabitForm from "./components/HabitForm.jsx";
import HabitList from "./components/HabitList.jsx";
import { api, setAuthToken } from "./api";

const App = () => {
  const [user, setUser] = useState(null);
  const [habits, setHabits] = useState([]);
  const [loadingHabits, setLoadingHabits] = useState(false);
  const [message, setMessage] = useState("");

  // Load token/user if present
  useEffect(() => {
    const token = localStorage.getItem("token");
    const userJson = localStorage.getItem("user");
    if (token && userJson) {
      setAuthToken(token);
      setUser(JSON.parse(userJson));
    }
  }, []);

  useEffect(() => {
    if (user) {
      fetchHabits();
    }
  }, [user]);

  const fetchHabits = async () => {
    setLoadingHabits(true);
    try {
      const res = await api.get("/habits");
      setHabits(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingHabits(false);
    }
  };

  const handleCreateHabit = async (data) => {
    try {
      const res = await api.post("/habits", data);
      setHabits((prev) => [res.data, ...prev]);
      setMessage("Habit created ✅");
      setTimeout(() => setMessage(""), 1500);
    } catch (err) {
      console.error(err);
    }
  };

  const handleCompleteHabit = async (id) => {
    try {
      const res = await api.patch(`/habits/${id}/complete`);
      setHabits((prev) => prev.map((h) => (h._id === id ? res.data : h)));
      setMessage("Marked as completed for today 🎯");
      setTimeout(() => setMessage(""), 1500);
    } catch (err) {
      const msg =
        err.response?.data?.message || "Could not mark completion today.";
      setMessage(msg);
      setTimeout(() => setMessage(""), 2000);
    }
  };

  const handleDeleteHabit = async (id) => {
    try {
      await api.delete(`/habits/${id}`);
      setHabits((prev) => prev.filter((h) => h._id !== id));
    } catch (err) {
      console.error(err);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setAuthToken(null);
    setUser(null);
    setHabits([]);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar user={user} onLogout={handleLogout} />
      <main className="flex-1 flex items-center justify-center px-4 py-8">
        {!user ? (
          <div className="flex flex-col items-center gap-6">
            <h1 className="text-2xl md:text-3xl font-bold text-center">
              Build better habits,
              <span className="text-emerald-400"> one day at a time.</span>
            </h1>
            <AuthForm onAuth={setUser} />
          </div>
        ) : (
          <div className="w-full max-w-3xl mx-auto">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h2 className="text-xl font-semibold">
                  Today&apos;s habits overview
                </h2>
                <p className="text-xs text-slate-400">
                  Track daily actions and watch your progress grow.
                </p>
              </div>
              {message && (
                <span className="text-xs px-3 py-1 rounded-full bg-slate-800 border border-slate-700 text-emerald-300">
                  {message}
                </span>
              )}
            </div>
            <HabitForm onCreate={handleCreateHabit} />
            {loadingHabits ? (
              <p className="text-sm text-slate-400 mt-4">Loading habits...</p>
            ) : (
              <HabitList
                habits={habits}
                onComplete={handleCompleteHabit}
                onDelete={handleDeleteHabit}
              />
            )}
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
