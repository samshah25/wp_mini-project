import React, { useState } from "react";
import { api, setAuthToken } from "../api";

const AuthForm = ({ onAuth }) => {
  const [mode, setMode] = useState("login"); // 'login' | 'register'
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: ""
  });
  const [error, setError] = useState("");

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      const endpoint = mode === "login" ? "/auth/login" : "/auth/register";
      const body =
        mode === "login"
          ? { email: form.email, password: form.password }
          : form;

      const res = await api.post(endpoint, body);
      const { token, user } = res.data;

      localStorage.setItem("token", token);
      localStorage.setItem("user", JSON.stringify(user));
      setAuthToken(token);
      onAuth(user);
    } catch (err) {
      setError(
        err.response?.data?.message || "Something went wrong, try again."
      );
    }
  };

  return (
    <div className="max-w-md w-full bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-lg">
      <div className="flex justify-between mb-4">
        <button
          className={`flex-1 py-2 rounded-xl text-sm ${
            mode === "login"
              ? "bg-emerald-500 text-slate-900 font-semibold"
              : "bg-slate-800 text-slate-300"
          }`}
          onClick={() => setMode("login")}
        >
          Login
        </button>
        <button
          className={`flex-1 py-2 ml-2 rounded-xl text-sm ${
            mode === "register"
              ? "bg-emerald-500 text-slate-900 font-semibold"
              : "bg-slate-800 text-slate-300"
          }`}
          onClick={() => setMode("register")}
        >
          Register
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-3">
        {mode === "register" && (
          <div>
            <label className="block text-xs mb-1 text-slate-300">Name</label>
            <input
              className="w-full rounded-xl bg-slate-800 border border-slate-700 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              name="name"
              value={form.name}
              onChange={handleChange}
              required={mode === "register"}
            />
          </div>
        )}
        <div>
          <label className="block text-xs mb-1 text-slate-300">Email</label>
          <input
            className="w-full rounded-xl bg-slate-800 border border-slate-700 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
            name="email"
            type="email"
            value={form.email}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label className="block text-xs mb-1 text-slate-300">Password</label>
          <input
            className="w-full rounded-xl bg-slate-800 border border-slate-700 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
            name="password"
            type="password"
            value={form.password}
            onChange={handleChange}
            required
          />
        </div>
        {error && <p className="text-xs text-red-400">{error}</p>}

        <button
          type="submit"
          className="w-full py-2 rounded-xl bg-emerald-500 text-slate-900 font-semibold text-sm hover:bg-emerald-400 transition"
        >
          {mode === "login" ? "Login" : "Create Account"}
        </button>
      </form>
    </div>
  );
};

export default AuthForm;
