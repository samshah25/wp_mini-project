import React, { useState } from "react";

const HabitForm = ({ onCreate }) => {
  const [name, setName] = useState("");
  const [goalPerWeek, setGoalPerWeek] = useState(7);

  const submit = (e) => {
    e.preventDefault();
    if (!name.trim()) return;
    onCreate({ name, goalPerWeek: Number(goalPerWeek) || 7 });
    setName("");
    setGoalPerWeek(7);
  };

  return (
    <form
      onSubmit={submit}
      className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row gap-3 items-center"
    >
      <input
        className="flex-1 rounded-xl bg-slate-800 border border-slate-700 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
        placeholder="Add a new habit (e.g. Drink water)"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <div className="flex items-center gap-2">
        <span className="text-xs text-slate-400">Goal / week</span>
        <input
          type="number"
          min="1"
          max="7"
          className="w-16 rounded-xl bg-slate-800 border border-slate-700 px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
          value={goalPerWeek}
          onChange={(e) => setGoalPerWeek(e.target.value)}
        />
      </div>
      <button
        type="submit"
        className="w-full md:w-auto px-4 py-2 rounded-xl bg-emerald-500 text-slate-900 font-semibold text-sm hover:bg-emerald-400 transition"
      >
        Add Habit
      </button>
    </form>
  );
};

export default HabitForm;
