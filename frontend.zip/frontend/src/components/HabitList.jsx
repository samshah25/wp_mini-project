import React from "react";
import HabitProgress from "./HabitProgress";

const HabitList = ({ habits, onComplete, onDelete }) => {
  if (!habits.length) {
    return (
      <p className="text-sm text-slate-400 mt-4">
        No habits yet. Add one to get started!
      </p>
    );
  }

  return (
    <div className="grid md:grid-cols-2 gap-4 mt-4">
      {habits.map((habit) => (
        <div
          key={habit._id}
          className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4"
        >
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-semibold text-sm">{habit.name}</h3>
              <p className="text-xs text-slate-400">
                Goal: {habit.goalPerWeek} times / week
              </p>
            </div>
            <div className="flex gap-2">
              <button
                className="text-xs px-3 py-1 rounded-full bg-emerald-500 text-slate-900 font-semibold hover:bg-emerald-400"
                onClick={() => onComplete(habit._id)}
              >
                Mark Today
              </button>
              <button
                className="text-xs px-3 py-1 rounded-full border border-red-500/60 text-red-300 hover:bg-red-500/10"
                onClick={() => onDelete(habit._id)}
              >
                ✕
              </button>
            </div>
          </div>
          <HabitProgress habit={habit} />
        </div>
      ))}
    </div>
  );
};

export default HabitList;
