import React from "react";

const getWeekStats = (habit) => {
  const now = new Date();
  const startOfWeek = new Date(now);
  const day = now.getDay(); // 0-6
  startOfWeek.setDate(now.getDate() - day); // Sunday as start
  startOfWeek.setHours(0, 0, 0, 0);

  const completionsThisWeek = habit.completions.filter((c) => {
    const d = new Date(c.date);
    return d >= startOfWeek && d <= now;
  }).length;

  const percentage = Math.min(
    100,
    Math.round((completionsThisWeek / habit.goalPerWeek) * 100)
  );

  return { completionsThisWeek, percentage };
};

const HabitProgress = ({ habit }) => {
  const { completionsThisWeek, percentage } = getWeekStats(habit);

  return (
    <div className="mt-2">
      <div className="flex justify-between text-xs text-slate-400 mb-1">
        <span>
          {completionsThisWeek}/{habit.goalPerWeek} this week
        </span>
        <span>{percentage}%</span>
      </div>
      <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
        <div
          className="h-full bg-emerald-500 transition-all"
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
};

export default HabitProgress;
