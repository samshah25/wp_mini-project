import React from "react";

const Navbar = ({ user, onLogout }) => {
  return (
    <nav className="w-full bg-slate-950 border-b border-slate-800 px-6 py-3 flex items-center justify-between">
      <span className="font-semibold text-lg">
        🧩 <span className="text-emerald-400">Habit</span>Tracker
      </span>
      {user && (
        <div className="flex items-center gap-4">
          <span className="text-sm text-slate-300">
            Hi, <span className="font-semibold">{user.name}</span>
          </span>
          <button
            className="text-xs px-3 py-1 rounded-full border border-slate-700 hover:bg-slate-800"
            onClick={onLogout}
          >
            Logout
          </button>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
